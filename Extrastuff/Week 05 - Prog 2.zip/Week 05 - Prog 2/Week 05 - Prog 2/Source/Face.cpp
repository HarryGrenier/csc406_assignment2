//
//  Ellipse.cpp
//

#include <iostream>
#include "glPlatform.h"
#include "Face.h"
#include "World.h"

using namespace std;


//	Prototypes for "file-level private" functions
int initCirclePoints();
void drawEllipse(float cx, float cy, float angle, float radiusX, float radiusY,
				 float r, float g, float b, bool drawContour);

//----------------------------
//	"private" global variables
//----------------------------

//	plenty enough for most cases
const int NUM_CIRCLE_PTS = 32;

//	Global variable storing the coordinates of a circle's vertices
float circleXY[NUM_CIRCLE_PTS][2];

int circlePointDefined = initCirclePoints();


Face::Face(float cx, float cy, float angle, float scale, float r,
			float g, float b)
	:	GraphicObject2D(cx, cy, angle, scale, r, g, b, false)
{
}

Face::Face(float cx, float cy, float angle, float scale, float r,
			float g, float b, float vx, float vy, float spin)
	:	GraphicObject2D(cx, cy, angle, scale, r, g, b, false, vx, vy, spin)
{
}


void Face::draw() const
{
	glPushMatrix();
	glTranslatef(cx_, cy_, 0.f);
	glRotatef(angle_, 0.f, 0.f, 1.f);
	glPushMatrix();
	glScalef(scale_, scale_, 1.f);

	// left ear
	drawEllipse(-1.1f, 0.5f, 0.f, 0.5f, 0.7f, 0.6f, 0.2f, 0.7f, false);
	//	right ear
	drawEllipse(1.1f, 0.5f, 0.f, 0.5f, 0.7f, 0.6f, 0.2f, 0.7f, false);
	//	face proper
	drawEllipse(0.f, 0.f, 0.f, 1.f, 2.f, 0.6f, 0.6f, 1.f, false);
	//	left eye
	drawEllipse(-0.5f, 0.5f, 0.f, 0.2f, 0.2f, 1.f, 1.f, 1.f, false);
	drawEllipse(-0.5f, 0.5f, 0.f, 0.1f, 0.1f, 0.2f, 0.2f, 0.8f, false);
	//	right  eye
	drawEllipse(+0.5f, 0.5f, 0.f, 0.2f, 0.2f, 1.f, 1.f, 1.f, false);
	drawEllipse(+0.5f, 0.5f, 0.f, 0.1f, 0.1f, 0.2f, 0.2f, 0.8f, false);
	//	mouth
	drawEllipse(+0.0f, -0.6f, 0.f, 0.4f, 0.2f, 0.4f, 0.2f, 0.8f, false);

	//	restore the reference frame w/o scaling
	glPopMatrix();

	drawReferenceFrame();

	//	restore the initial reference
	glPopMatrix();
}

//	To be improved (a lot) by using display listss
void drawEllipse(float cx, float cy, float angle, float radiusX, float radiusY,
				 float r, float g, float b, bool drawContour)
{
	glPushMatrix();
	glTranslatef(cx, cy, 0.f);
	glRotatef(angle, 0.f, 0.f, 0.f);
	glScalef(radiusX, radiusY, 1.f);
	
	glColor3f(r, g, b);
	glBegin(GL_POLYGON);
	for (int k=0; k<NUM_CIRCLE_PTS; k++)
		glVertex2f(circleXY[k][0], circleXY[k][1]);
	glEnd();
	glPopMatrix();
}
	
int initCirclePoints()
{
	for (int k=0; k<NUM_CIRCLE_PTS; k++)
	{
		float angle = 2*k*M_PI / NUM_CIRCLE_PTS;
		circleXY[k][0] = cosf(angle);
		circleXY[k][1] = sinf(angle);
	}
	return 1;
}
