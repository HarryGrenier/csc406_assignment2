//
//  prog1.cpp
//
//	New stuff:
//		scale and spin moved to GraphicObject2D class
//		drawReferenceFrame and matching flag moved to World.cpp
//		Face class
//		use of modern C++  generation of pseudo-random numbers

//	Very basic interface with limited keyboard action:
//		- 'q' or ESC exits the app,
//		- 'm' toggles on/off mouse motion tracking (button pressed)
//		- 'p' toggles on/off passive mouse motion tracking (no button pressed)
//		- 'e' toggles on/off mouse exit/enter
//		- 't' toggles on/off text overlay display
//		- 'b' toggles on/off text background display
//		- 'i' activates the input of a second text string
//			(input from the terminal)
//		- clicking the mouse anywhere in the window will print out
//			pixel location of the click, conversion in world coordinates, and
//			conversion back to pixels (for verification).
//
//	Initial aspect ratio of the window is preserved when the window
//	is resized.
//
//  Created by Jean-Yves Hervé on 2024-10-01.
//

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <random>
#include <chrono>
#include <ctime>
//
#include "glPlatform.h"
#include "World.h"
#include "Square.h"
#include "Rectangle.h"
#include "Ellipse.h"
#include "Triangle.h"
#include "Face.h"

using namespace std;

#if 0
//--------------------------------------
#pragma mark -
#pragma mark Custom data types
//--------------------------------------
#endif

//	I like to setup my meny item indices as enmerated values, but really
//	regular int constants would do the job just fine.
//	Note that in modern C++, it's generally advised to use "scoped enums", which
//	are declared as "enum class NameOfType".  I agree and do so in general, but
//	here these are meant to be used with my glut interface, and it's really
//	bothersome to do the casting to int each each time.


enum MenuItemID {	SEPARATOR = -1,
					//
					QUIT_MENU = 0,
					OTHER_MENU_ITEM,
					SOME_ITEM = 10
};

enum TextColorSubmenuItemID {	FIRST_TEXT = 11,
								RED_TEXT = 11,
								GREEN_TEXT,
								WHITE_TEXT,
								MAGENTA_TEXT,
								//
								MAX_COUNT_TEXT
};
const int NUM_TEXT_COLORS = MAX_COUNT_TEXT - FIRST_TEXT;

enum BackgroundColorSubmenuItemID {	FIRST_BGND = 21,
									LIGHT_GREY_BGND = 21,
									DARK_GREY_BGND,
									GREEN_BGND,
									BLUE_BGND,
									BROWN_BGND,
									//
									MAX_COUNT_BGND
};
const int NUM_BGND_COLORS = MAX_COUNT_BGND - FIRST_BGND;

enum FontSize {
					SMALL_FONT_SIZE = 0,
					MEDIUM_FONT_SIZE,
					LARGE_FONT_SIZE,
					//
					NUM_FONT_SIZES
};

#if 0
//--------------------------------------
#pragma mark -
#pragma mark Function prototypes
//--------------------------------------
#endif

void displayTextualInfo(const string& infoStr, int textRow);
void displayTextualInfo(const char* infoStr, int textRow);
void myDisplayFunc(void);
void myResizeFunc(int w, int h);
void myMouseHandler(int b, int s, int x, int y);
void myMouseMotionHandler(int x, int y);
void myMousePassiveMotionHandler(int x, int y);
void myEntryHandler(int state);
void myKeyHandler(unsigned char c, int x, int y);
void myMenuHandler(int value);
void mySubmenuHandler(int colorIndex);
void myTimerFunc(int val);
void applicationInit();
//
void drawSquare(float cx, float cy, float size, float r,
                    float g, float b, bool contour);

#if 0
//--------------------------------------
#pragma mark -
#pragma mark Constants
//--------------------------------------
#endif

const int 	INIT_WIN_X = 10,
			INIT_WIN_Y = 32;
const float X_MIN = -10.f, X_MAX = +10.f;
const float Y_MIN = -10.f, Y_MAX = +10.f;

const float MAX_SPIN = 100.f;	//	degree per second
const float MIN_TIME_TO_CROSS = 5.f;
const float MAX_SPEED = (X_MAX - X_MIN) / MIN_TIME_TO_CROSS;
const float MIN_SIZE = (X_MAX - X_MIN) / 30;
const float MAX_SIZE = (X_MAX - X_MIN) / 10;

#define SMALL_DISPLAY_FONT    GLUT_BITMAP_HELVETICA_10
#define MEDIUM_DISPLAY_FONT   GLUT_BITMAP_HELVETICA_12
#define LARGE_DISPLAY_FONT    GLUT_BITMAP_HELVETICA_18
const int H_PAD = 10;
const int V_PAD = 5;

const string TEXT_COLOR_STR[NUM_TEXT_COLORS] = {"white",		//	WHITE_TEXT
												"red",			//	RED_TEXT
												"green",		//	GREEN_TEXT
												"magenta"};		//	MAGENTA_TEXT
							
const string BGND_COLOR_STR[NUM_BGND_COLORS] = {"light gray",	//	LIGHT_GREY_BGND
												"dark gray",	//	DARK_GREY_BGND
												"green",		//	GREEN_BGND
												"blue",			//	BLUE_BGND
												"brown"};		//	BROWN_BGND

const GLfloat TEXT_COLOR[NUM_TEXT_COLORS][3] = { {1.f, 1.f, 1.f},	//	WHITE_TEXT
												 {1.f, 0.f, 0.f},	//	RED_TEXT
												 {0.f, .8f, 0.f},	//	GREEN_TEXT
												 {1.f, 0.f, 1.f}};	//	MAGENTA_TEXT
							
const GLfloat BGND_COLOR[NUM_BGND_COLORS][3] = { {.5f, .5f, .5f},	//	LIGHT_GREY_BGND
												 {.3f, .3f, .3f},	//	DARK_GREY_BGND
												 {0.f, .4f, 0.f},	//	GREEN_BGND
												 {0.f, 0.f, .4f},	//	BLUE_BGND
												 {.4f, .2f, 0.f}};	//	BROWN_BGND

const bool displayTextOnLeft = false;
const bool displayTextOnTop = true;
const FontSize fontSize = LARGE_FONT_SIZE;



#if 0
//--------------------------------------
#pragma mark -
#pragma mark File-level Global variables
//--------------------------------------
#endif

time_t startTime = -1;
int winWidth = 800,
    winHeight = 800;

bool trackEntry = false;
bool trackMousePointer = false;
bool trackPassiveMousePointer = false;
bool pointerInWindow = false;
GLint lastX = -1, lastY = -1;

bool displayText = false;
bool displayBgnd = false;
string stringLine = "";
const GLfloat* textColor = TEXT_COLOR[0];
const GLfloat* bgndColor = BGND_COLOR[0];

WorldType World::worldType = BOX_WORLD;
bool World::drawReferenceFrames = false;

vector<shared_ptr<GraphicObject2D> > objList;

int physicsHeartBeat = 1;	// milliseconds
int renderRate = 10;		//	1 rendering frame for 10 simulation heartbeats
bool isAnimated = true;
bool animationJustStarted = false;

random_device myRandDev;
default_random_engine myEngine(myRandDev());
uniform_int_distribution<int> shapeDist(0, 4);	//	triangle - square - face - rect - ellipse
uniform_real_distribution<float> angleDist(0, 2*M_PI);
uniform_real_distribution<float> colorDist(0.f, 1.f);
uniform_real_distribution<float> spinDist(-MAX_SPIN, +MAX_SPIN);
uniform_real_distribution<float> speedDist(0.4f*MAX_SPEED, MAX_SPEED);
uniform_real_distribution<float> sizeDist(MIN_SIZE, MAX_SIZE);


#if 0
//--------------------------------------
#pragma mark -
#pragma mark Callback functions
//--------------------------------------
#endif

//	This is the function that does the actual scene drawing
//	Typically, you shold almost never have to call this function directly yourself.
//	It will be called automatically by glut, the way in Java the JRE invokes the paint
//	method of a frame.  Simply, because there is no inheritance/overriding mechanism, we
//	need to set up this function as a "callback function."  In this demo I do it in the
//	main function.  A plus side of this way of doing is that the function can be named any way
//	we want, and that in fact we can have different display functions and change during
//	the execution of the program the current display function used by glut.
//
void myDisplayFunc(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glPushMatrix();
	
	//--------------------------
	//	basic drawing code
	//--------------------------

	for (auto obj : objList)
		obj->draw();

	//	Display textual info
	//---------------------------------
	//	We are back at the world's origin (by the glPopMatrix() just above), in world coordinates.
	//	So we must undo the scaling to be back in pixels, which how text is drawn for now.
	if (displayText)
	{
	//	First, translate to the upper-left corner
		glTranslatef(World::X_MIN, World::Y_MAX, 0.f);
		
		//	Then reverse the scaling: back in pixels, making sure that y now points down
		glScalef(World::drawInPixelScale, -World::drawInPixelScale, 1.f);

		char statusLine[256];
		sprintf(statusLine, "Runtime: %d s   |   Number of objects: %d   |   Mouse last seen at (%d, %d)",
								static_cast<int>(time(nullptr)-startTime),
								static_cast<int>(objList.size()),
								lastX, lastY);
		displayTextualInfo(statusLine, 0);		//	first row

		if (stringLine != "")
		displayTextualInfo(stringLine, 1);		//	second row
	}

	glPopMatrix();
	
	drawReferenceFrame();

	//	We were drawing into the back buffer(s), now they should be brought
	//	to the forefront.  This will be explained in a few weeks.
	glutSwapBuffers();
}

void drawSquare(float cx, float cy, float size, float r,
                    float g, float b, bool drawContour)
{
	float halfSize = 0.5f*size;
	
	glColor3f(r, g, b);
	glBegin(GL_POLYGON);
		glVertex2f(cx - halfSize, cy - halfSize);
		glVertex2f(cx + halfSize, cy - halfSize);
		glVertex2f(cx + halfSize, cy + halfSize);
		glVertex2f(cx - halfSize, cy + halfSize);
	glEnd();

	if (drawContour)
	{
		// simply invert the filling color
		glColor3f(1.f-r, 1.f-g, 1.f-b);
		glBegin(GL_LINE_LOOP);
			glVertex2f(cx - halfSize, cy - halfSize);
			glVertex2f(cx + halfSize, cy - halfSize);
			glVertex2f(cx + halfSize, cy + halfSize);
			glVertex2f(cx - halfSize, cy + halfSize);
		glEnd();
	}
}
				

//	This callback function is called when the window is resized
//	(generally by the user of the application).
//	It is also called when the window is created, which is why I placed there the
//	code to set up the virtual camera for this application.
//
void myResizeFunc(int w, int h)
{
	winWidth = w;
    winHeight = h;
	
	World::setWorldBounds(X_MIN, X_MAX, Y_MIN, Y_MAX, winWidth, winHeight);
	if (winWidth != w || winHeight != h)
	{
		glutReshapeWindow(winWidth, winHeight);
	}
	
	//	This calls says that I want to use the entire dimension of the window for my drawing.
	glViewport(0, 0, winWidth, winHeight);

	//	Here I create my virtual camera.  We are going to do 2D drawing for a while, so what this
	//	does is define the dimensions (origin and units) of the "virtual world that my viewport
	//	maps to.
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	//	Here I define the dimensions of the "virtual world" that my
	//	window maps to
	gluOrtho2D(X_MIN, X_MAX, Y_MIN, Y_MAX);

	//	When it's done, request a refresh of the display
	glutPostRedisplay();
 }


//	This function is called when a mouse event occurs.  This event, of type s
//	(up, down, dragged, etc.), occurs on a particular button of the mouse.
//
void myMouseHandler(int button, int state, int ix, int iy)
{
	switch (button)
	{
		case GLUT_LEFT_BUTTON:
			if (state == GLUT_DOWN)
			{
				//	do something
				//	do something
				cout << "Click at: (" << ix << ", " << iy << ")" << endl;
				Point wPt = pixelToWorld(ix, iy);
				cout << "Corresponding world point: (" << wPt.x << ", " <<
						wPt.y << ")" << endl;
				Point pPt = worldToPixel(wPt.x, wPt.y);
				cout << "Back to pixels: (" << pPt.x << ", " <<
						pPt.y << ")" << endl;
				
			}
			else if (state == GLUT_UP)
			{
				Point wpt = pixelToWorld(ix, iy);
				float angle = angleDist(myEngine);
				float direction = angleDist(myEngine);
				float speed = speedDist(myEngine);
				float spin = spinDist(myEngine);
				float r = colorDist(myEngine), g = colorDist(myEngine), b = colorDist(myEngine);
				
				switch(shapeDist(myEngine))
				{
					case 0:
						objList.push_back(make_shared<Square>(wpt.x, wpt.y, angle, sizeDist(myEngine), r, g, b, true,
											speed*cosf(direction), speed*sinf(direction), spin));
					break;

					case 1:
					objList.push_back(make_shared<Triangle>(wpt.x, wpt.y, angle, sizeDist(myEngine), r, g, b, true,
										speed*cosf(direction), speed*sinf(direction), spin));
					break;

					case 2:
					objList.push_back(make_shared<Face>(wpt.x, wpt.y, angle, sizeDist(myEngine), r, g, b,
										speed*cosf(direction), speed*sinf(direction), spin));
					break;

					case 3:
					objList.push_back(make_shared<Rectangle>(wpt.x, wpt.y, angle, sizeDist(myEngine), sizeDist(myEngine), r, g, b, true,
										speed*cosf(direction), speed*sinf(direction), spin));
					break;

					case 4:
					objList.push_back(make_shared<Ellipse>(wpt.x, wpt.y, angle, sizeDist(myEngine), sizeDist(myEngine), r, g, b, true,
										speed*cosf(direction), speed*sinf(direction), spin));
					break;

					default:
					break;
				}
			}
			break;
			
		default:
			break;
	}
}


void myMouseMotionHandler(int ix, int iy)
{
	if (trackMousePointer)
	{
		cout << "Active mouse at (" << ix << ", " << iy << ")" << endl;
	}
}
void myMousePassiveMotionHandler(int ix, int iy)
{
	lastX = ix;
	lastY = iy;
	pointerInWindow = (ix >= 0 && ix < winWidth && iy >= 0 && iy < winHeight);

	if (trackPassiveMousePointer)
	{
		cout << "Passive mouse at (" << ix << ", " << iy << ")" << endl;
	}

}
void myEntryHandler(int state)
{
	if (trackEntry)
	{
		if (state == GLUT_ENTERED)
		{
			pointerInWindow = true;
			cout << "===> Pointer entered" << endl;
		}
		else	// GLUT_LEFT
		{
			pointerInWindow = false;
			cout << "<=== Pointer exited" << endl;
		}
	}
}

//	This callback function is called when a keyboard event occurs
//
void myKeyHandler(unsigned char c, int x, int y)
{
	// silence warning
	(void) x;
	(void) y;
	
	switch (c)
	{
		case 'q':
		case 27:
			exit(0);
			break;
		
		case ' ':
			isAnimated = !isAnimated;
			if (isAnimated)
				animationJustStarted = true;
			break;
			
		case 'm':
			trackMousePointer = !trackMousePointer;
			break;

		case 'p':
			trackPassiveMousePointer = !trackPassiveMousePointer;
			break;
			
		case 'e':
			trackEntry = !trackEntry;
			break;
			
		case 'i':
			cout << "Enter a new line of text: ";
			getline(cin, stringLine);
			break;
		
		case 'f':
			World::drawReferenceFrames = !World::drawReferenceFrames;
			break;
			
		case 't':
			displayText = !displayText;
			
		case 'b':
			displayBgnd = !displayBgnd;
			break;
			
		default:
			break;
	}
}

void myTimerFunc(int value)
{
	static int updateFrameIndex=0;
	static chrono::high_resolution_clock::time_point lastTime = chrono::high_resolution_clock::now();

	// re-prime the timer
	glutTimerFunc(physicsHeartBeat, myTimerFunc, value);

	if (isAnimated)
	{
		chrono::high_resolution_clock::time_point currentTime = chrono::high_resolution_clock::now();
		float dt = chrono::duration_cast<chrono::duration<float> >(currentTime - lastTime).count();
		if (animationJustStarted)
		{
			dt = 0.f;
			animationJustStarted = false;
		}
		lastTime = currentTime;

		for (auto obj : objList)
			obj->update(dt);

	}
	
	//	And finally I perform the rendering
	//	ideally not as often as physics update
	if (updateFrameIndex++ % renderRate == 0)
		glutPostRedisplay();
}



//	This  is where the menu item selected is identified.  This is
//	why  we need a unique code per menu item.
void myMenuHandler(int choice)
{
	switch (choice)
	{
		//	Exit/Quit
		case QUIT_MENU:
			exit(0);
			break;
		
		//	Do something
		case OTHER_MENU_ITEM:
			break;
		
		default:	//	this should not happen
			break;
	
	}

    glutPostRedisplay();
}

//  in this example my submenu selection indicates the keyboard handling
//  function to use.
void mySubmenuHandler(int choice)
{
	switch (choice)
	{
		case RED_TEXT:
		case GREEN_TEXT:
		case WHITE_TEXT:
		case MAGENTA_TEXT:
			textColor = TEXT_COLOR[choice - FIRST_TEXT];
			break;
			
		case LIGHT_GREY_BGND:
		case DARK_GREY_BGND:
		case GREEN_BGND:
		case BLUE_BGND:
		case BROWN_BGND:
			bgndColor = BGND_COLOR[choice - FIRST_BGND];
			break;
		
		default:
			break;
	}
}

#if 0
//--------------------------------------
#pragma mark -
#pragma mark Utilities
//--------------------------------------
#endif

void displayTextualInfo(const string& infoStr, int textRow){
	displayTextualInfo(infoStr.c_str(), textRow);
}

void displayTextualInfo(const char* infoStr, int textRow)
{
    //-----------------------------------------------
    //  0.  Build the string to display <-- parameter
    //-----------------------------------------------
    int infoLn = static_cast<int> (strlen(infoStr));

    //-----------------------------------------------
    //  1.  Determine the string's length (in pixels)
    //-----------------------------------------------
    int textWidth = 0, fontHeight=-1;
	switch(fontSize)
	{
		case SMALL_FONT_SIZE:
			fontHeight = 10;
			for (int k=0; k<infoLn; k++)
			{
				textWidth += glutBitmapWidth(SMALL_DISPLAY_FONT, infoStr[k]);
			}
			break;
		
		case MEDIUM_FONT_SIZE:
			fontHeight = 12;
			for (int k=0; k<infoLn; k++)
			{
				textWidth += glutBitmapWidth(MEDIUM_DISPLAY_FONT, infoStr[k]);
			}
			break;
		
		case LARGE_FONT_SIZE:
			fontHeight = 16;
			for (int k=0; k<infoLn; k++)
			{
				textWidth += glutBitmapWidth(LARGE_DISPLAY_FONT, infoStr[k]);
			}
			break;
			
		default:
			break;
	}

    //-----------------------------------------------
    //  2.  get current material properties
    //-----------------------------------------------
    float oldAmb[4], oldDif[4], oldSpec[4], oldShiny;
    glGetMaterialfv(GL_FRONT, GL_AMBIENT, oldAmb);
    glGetMaterialfv(GL_FRONT, GL_DIFFUSE, oldDif);
    glGetMaterialfv(GL_FRONT, GL_SPECULAR, oldSpec);
    glGetMaterialfv(GL_FRONT, GL_SHININESS, &oldShiny);

    glPushMatrix();
	if (displayTextOnTop)
    {
		glTranslatef(0.f, textRow*(fontHeight+2*V_PAD), 0.f);
    }
	else
    {
		glTranslatef(0.f, winHeight - (textRow+1)*(fontHeight+2*V_PAD),0.f);
	}

    //-----------------------------------------------
    //  3.  Clear background rectangle if required
    //-----------------------------------------------
    if (displayBgnd)
    {
		glColor3fv(bgndColor);
		glBegin(GL_POLYGON);
			glVertex2i(0, 0);
			glVertex2i(0, fontHeight + 2*V_PAD);
			glVertex2i(winWidth, fontHeight + 2*V_PAD);
			glVertex2i(winWidth, 0);
		glEnd();
	}
	
	//	Move "up" from current plane, to make sure that we overwrite
	glTranslatef(0.f, 0.f, 0.1f);

    //-----------------------------------------------
    //  4.  Draw the string
    //-----------------------------------------------    
    //	Where do we start drawing from
    int xPos = displayTextOnLeft ? H_PAD : winWidth - textWidth - H_PAD;
    int yPos = fontHeight + V_PAD;

    glColor3fv(textColor);
    int x = xPos;
	switch(fontSize)
	{
		case SMALL_FONT_SIZE:
			for (int k=0; k<infoLn; k++)
			{
				glRasterPos2i(x, yPos);
				glutBitmapCharacter(SMALL_DISPLAY_FONT, infoStr[k]);
				x += glutBitmapWidth(SMALL_DISPLAY_FONT, infoStr[k]);
			}
			break;
		
		case MEDIUM_FONT_SIZE:
			for (int k=0; k<infoLn; k++)
			{
				glRasterPos2i(x, yPos);
				glutBitmapCharacter(MEDIUM_DISPLAY_FONT, infoStr[k]);
				x += glutBitmapWidth(MEDIUM_DISPLAY_FONT, infoStr[k]);
			}
			break;
		
		case LARGE_FONT_SIZE:
			for (int k=0; k<infoLn; k++)
			{
				glRasterPos2i(x, yPos);
				glutBitmapCharacter(LARGE_DISPLAY_FONT, infoStr[k]);
				x += glutBitmapWidth(LARGE_DISPLAY_FONT, infoStr[k]);
			}
			break;
			
		default:
			break;
	}

    //-----------------------------------------------
    //  5.  Restore old material properties
    //-----------------------------------------------
	glMaterialfv(GL_FRONT, GL_AMBIENT, oldAmb);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, oldDif);
	glMaterialfv(GL_FRONT, GL_SPECULAR, oldSpec);
	glMaterialf(GL_FRONT, GL_SHININESS, oldShiny);  
    
    //-----------------------------------------------
    //  6.  Restore reference frame
    //-----------------------------------------------
    glPopMatrix();
}

void printMatrix(const GLfloat* m) {
    cout << "((" << m[0] << "\t" << m[4] << "\t" << m[8] << "\t" << m[12] << ")" << endl;
    cout << " (" << m[1] << "\t" << m[5] << "\t" << m[9] << "\t" << m[13] << ")" << endl;
    cout << " (" << m[2] << "\t" << m[6] << "\t" << m[10] << "\t" << m[14] << ")" << endl;
    cout << " (" << m[3] << "\t" << m[7] << "\t" << m[11] << "\t" << m[15] << "))" << endl;
}

#if 0
//--------------------------------------
#pragma mark -
#pragma mark Application init and main
//--------------------------------------
#endif

void applicationInit()
{
	// Create Menus
	int myMenu;
	
	//	Submenu for changing keyboard handling function
	int myTextColorSubmenu = glutCreateMenu(mySubmenuHandler);
	for (int k=0, t=FIRST_TEXT; k<NUM_TEXT_COLORS; k++, t++)
		glutAddMenuEntry(TEXT_COLOR_STR[k].c_str(), t);
	int myBgndColorSubmenu = glutCreateMenu(mySubmenuHandler);
	for (int k=0, b=FIRST_BGND; k<NUM_BGND_COLORS; k++, b++)
		glutAddMenuEntry(BGND_COLOR_STR[k].c_str(), b);

	// Main menu that the submenus are connected to
	myMenu = glutCreateMenu(myMenuHandler);
	glutAddMenuEntry("Quit", MenuItemID::QUIT_MENU);
	//
	glutAddMenuEntry("-", MenuItemID::SEPARATOR);
	glutAddMenuEntry("Other stuff", MenuItemID::OTHER_MENU_ITEM);
	glutAddMenuEntry("New entry", 64);
	
	glutAddMenuEntry("-", MenuItemID::SEPARATOR);
	glutAddSubMenu("Text color:", myTextColorSubmenu);
	glutAddSubMenu("Background color:", myBgndColorSubmenu);
	glutAddMenuEntry("-", MenuItemID::SEPARATOR);
	glutAttachMenu(GLUT_RIGHT_BUTTON);

//	//green square
	objList.push_back(make_shared<Square>(6.5f, 3.5f, 0.f, 1.f, 0.f, 1.0f, 0.f, true, 0.5f, 1.f, 5.f));
	// red square
	objList.push_back(make_shared<Square>(-2.f, -5.f, 30.f, 2.f, 1.f, 0.f, 0.f, true, 0.f, 0.f, -10.f));

	objList.push_back(make_shared<Triangle>(5.f, 5.f, 90.f, 1.f, 0, 0, 1, true));
	objList.push_back(make_shared<Triangle>(2.f, 6.0f, 60.f, 0.5f, 1, 1, 0, false, 0.f, 0.f, -6.f));
	
	//	A face
	objList.push_back(make_shared<Face>(-4.f, 2.f, 0.f, 1.f, 1, 1, 0));
	objList.push_back(make_shared<Face>(4.f, 2.f, 0.f, 2.f, 1, 1, 0));
	
	//	time really starts now
	startTime = time(nullptr);
}

int main(int argc, char * argv[])
{
	//	Initialize glut and create a new window
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);

	glutInitWindowSize(winWidth, winHeight);
	glutInitWindowPosition(INIT_WIN_X, INIT_WIN_Y);
	glutCreateWindow("demo CSC406");
	
	//	set up the callbacks
	glutDisplayFunc(myDisplayFunc);
	glutReshapeFunc(myResizeFunc);
	glutMouseFunc(myMouseHandler);
	glutMotionFunc(myMouseMotionHandler);
	glutPassiveMotionFunc(myMousePassiveMotionHandler);
	glutEntryFunc(myEntryHandler);
	glutKeyboardFunc(myKeyHandler);
	glutTimerFunc(physicsHeartBeat,	myTimerFunc,		0);
	//			  time	    name of		value to pass
	//			  in ms		function	to the func
	
	//	Now we can do application-level
	applicationInit();

	//	Now we enter the main loop of the program and to a large extend
	//	"lose control" over its execution.  The callback functions that
	//	we set up earlier will be called when the corresponding event
	//	occurs
	glutMainLoop();
	
	//	This will never be executed (the exit point will be in one of the
	//	callback functions).
	return 0;
}
