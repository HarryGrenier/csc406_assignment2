//
//  Rectangle.cpp
//
//  Created by Jean-Yves Hervé on 2023-09-14.
//

#include <cmath>
#include <iostream>
#include "glPlatform.h"
#include "Rectangle.h"

using namespace std;

Rectangle::Rectangle(float centerX, float centerY, float angle, float width, float height,
				float r, float g, float b, bool drawContour)
	:	GraphicObject2D(centerX, centerY, angle, 1.f, r, g, b, drawContour),
		//
		width_(width),
		height_(height)
{
}

Rectangle::Rectangle(float centerX, float centerY, float angle, float width, float height,
				float r, float g, float b, bool drawContour, float vx, float vy, float spin)
	:	GraphicObject2D(centerX, centerY, angle, 1.f, r, g, b, drawContour, vx, vy, spin),
		//
		width_(width),
		height_(height)
{
}

void Rectangle::draw() const
{
	//	save the current coordinate system (origin, axes, scale)
	glPushMatrix();
	
	//	move to the center of the disk
	glTranslatef(cx_, cy_, 0.f);
		
	// apply rotation
	glRotatef(angle_, 0.f, 0.f, 1.f);
	
	//	apply the radius as a scale
	glScalef(width_, height_, 1.f);
	
	glColor3f(r_, g_, b_);
	glBegin(GL_POLYGON);
		glVertex2f(-0.5f, -0.5f);
		glVertex2f(+0.5f, -0.5f);
		glVertex2f(+0.5f, +0.5f);
		glVertex2f(-0.5f, +0.5f);
	glEnd();
	
	if (drawContour_)
	{
		glColor3f(1.f - r_, 1.f - g_, 1.f - b_);
		glBegin(GL_LINE_LOOP);
			glVertex2f(-0.5f, -0.5f);
			glVertex2f(+0.5f, -0.5f);
			glVertex2f(+0.5f, +0.5f);
			glVertex2f(-0.5f, +0.5f);
		glEnd();
	}
	
	//	restore the original coordinate system (origin, axes, scale)
	glPopMatrix();
}

