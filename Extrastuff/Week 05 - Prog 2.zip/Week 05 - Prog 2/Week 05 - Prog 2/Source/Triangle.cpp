//
//  Triangle.cpp
//  Week 05 - Prog 1
//
//  Created by Jean-Yves Hervé on 2024-09-10.
//

#include <iostream>
#include <cmath>

#include "glPlatform.h"
#include "World.h"
#include "Triangle.h"

using namespace std;

unsigned int Triangle::count_ = 0;
float Triangle::xy_[3][2] = {{1.f, 0.f},
							 {cosf(2*M_PI/3), sinf(2*M_PI/3)},
							 {cosf(2*M_PI/3), -sinf(2*M_PI/3)}};


Triangle::Triangle(float cx, float cy, float angle, float radius, float r,
			float g, float b, bool drawContour)
	:	GraphicObject2D(cx, cy, angle, radius, r, g, b, drawContour),
		//
 		idx_(count_++)
{
}

Triangle::Triangle(float cx, float cy, float angle, float radius, float r,
			float g, float b, bool drawContour, float vx, float vy, float spin)
	:	GraphicObject2D(cx, cy, angle, radius, r, g, b, drawContour, vx, vy, spin),
		//
		idx_(count_++)
{
}

void Triangle::draw() const
{
	//	save the initial reference frame
	glPushMatrix();
	
	//	 position at the center of the triangle
	glTranslatef(cx_, cy_, 0.f);
	glRotatef(angle_, 0, 0, 1);
	glScalef(scale_, scale_, 1.f);
	
	glColor3f(r_, g_, b_);
	glBegin(GL_POLYGON);
		//	 vertex coordinates are relative to the center of the triangle
		glVertex2fv(xy_[0]);
		glVertex2fv(xy_[1]);
		glVertex2fv(xy_[2]);
	glEnd();

	if (drawContour_)
	{
		// simply invert the filling color
		glColor3f(1.f-r_, 1.f-g_, 1.f-b_);
		glBegin(GL_LINE_LOOP);
			//	 vertex coordinates are relative to the center of the triangle
			glVertex2fv(xy_[0]);
			glVertex2fv(xy_[1]);
			glVertex2fv(xy_[2]);
		glEnd();
	}
	
	if (World::drawReferenceFrames)
		drawReferenceFrame();

	//	restore the initial reference frame
	glPopMatrix();
}

void Triangle::update(float dt)
{
	//	call function of the parent class
	GraphicObject2D::update(dt);
	
	// change color:  make more green as time passes
	g_ += 0.3f*dt;
	if (g_ > 1.f)
		g_ = 1.f;
}
