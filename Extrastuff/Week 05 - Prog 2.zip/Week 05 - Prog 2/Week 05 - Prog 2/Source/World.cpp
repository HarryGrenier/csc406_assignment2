
#include <cmath>
#include "glPlatform.h"
#include "World.h"

float World::X_MIN;
float World::X_MAX;
float World::Y_MIN;
float World::Y_MAX;
float World::WIDTH;
float World::HEIGHT;
float World::pixelToWorldRatio;
float World::worldToPixelRatio;
float World::drawInPixelScale;

Point pixelToWorld(float ix, float iy)
{
	return Point{	World::X_MIN + ix*World::pixelToWorldRatio,
					World::Y_MAX - iy*World::pixelToWorldRatio
				};
}

Point worldToPixel(float wx, float wy)
{
	return Point{(wx - World::X_MIN)*World::worldToPixelRatio,
				 (World::Y_MAX - wy)*World::worldToPixelRatio};

}

void World::setWorldBounds(float xmin, float xmax, float ymin, float ymax,
						   int& paneWidth, int& paneHeight){
	if ((xmax <= xmin) || (ymax <= xmin)){
		exit(5);
	}
	X_MIN = xmin;
	X_MAX = xmax;
	Y_MIN = ymin;
	Y_MAX = ymax;
	WIDTH = xmax - xmin;
	HEIGHT = ymax - ymin;
	
	float widthRatio = WIDTH / paneWidth;
	float heightRatio = HEIGHT / paneHeight;
	float maxRatio = fmax(widthRatio,heightRatio);
//	Removed because this doesn’t work happily with interactive window resizing,
//	// If the two ratios differ by more than 5%,  then reject the dimensions
//	if (fabsf(widthRatio-heightRatio)/maxRatio > 0.05){
//		exit(15);
//	}

	pixelToWorldRatio = maxRatio;
	worldToPixelRatio = 1.f / pixelToWorldRatio;
	drawInPixelScale = pixelToWorldRatio;
	
	paneWidth = static_cast<int>(round(WIDTH * worldToPixelRatio));
	paneHeight = static_cast<int>(round(HEIGHT * worldToPixelRatio));
}

void drawReferenceFrame(void)
{
	if (World::drawReferenceFrames)
	{
		glLineWidth(2.f);
		glPushMatrix();
		//	switch to pixels
		glScalef(World::drawInPixelScale, World::drawInPixelScale, 1.f);
		glBegin(GL_LINES);
			//	X --> red.
			glColor3f(1.0f, 0.f, 0.f);
			glVertex2f(-10.f, 0.f);
			glVertex2f(50.f, 0.f);
			//	Y --> green
			glColor3f(0.f, 1.0f, 0.f);
			glVertex2f(0.f, -10.f);
			glVertex2f(0.f, 50.f);
		glEnd();
		//	back to  world units
		glPopMatrix();
		glLineWidth(1.f);
	}
}
