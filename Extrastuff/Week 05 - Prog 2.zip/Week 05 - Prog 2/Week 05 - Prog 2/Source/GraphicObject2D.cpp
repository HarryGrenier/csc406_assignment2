//
//  GraphicObject2D.cpp
//  Week 05 - Prog 1
//
//  Created by Jean-Yves Hervé on 2024-09-19.
//

#include "GraphicObject2D.h"

GraphicObject2D::GraphicObject2D(float cx, float cy, float angle, float scale,
					float r, float g, float b, bool drawContour)
	:	cx_(cx),
		cy_(cy),
		angle_(angle),
		scale_(scale),
		r_(r),
		g_(g),
		b_(b),
		drawContour_(drawContour),
		vx_(0),
		vy_(0),
		spin_(0)
{
}

GraphicObject2D::GraphicObject2D(float cx, float cy, float angle, float scale,
						float r, float g, float b, bool drawContour,
						float vx, float vy, float spin)
	:	cx_(cx),
		cy_(cy),
		angle_(angle),
		scale_(scale),
		r_(r),
		g_(g),
		b_(b),
		drawContour_(drawContour),
		vx_(vx),
		vy_(vy),
		spin_(spin)
{
}

// For future:  Handle edge-of-world problem --> WEEK 5
void GraphicObject2D::update(float dt)
{
	cx_ += vx_*dt;
	cy_ += vy_*dt;
	angle_ += spin_*dt;
}



