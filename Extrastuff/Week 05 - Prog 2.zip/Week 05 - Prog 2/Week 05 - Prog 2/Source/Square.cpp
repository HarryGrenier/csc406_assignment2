//
//  Square.cpp
//  Week 05 - Prog 1
//
//  Created by Jean-Yves Hervé on 2024-09-10.
//

#include <iostream>

#include "glPlatform.h"
#include "World.h"
#include "Square.h"

using namespace std;

unsigned int Square::count_ = 0;


Square::Square(float cx, float cy, float angle, float size, float r,
			float g, float b, bool drawContour)
	:	GraphicObject2D(cx, cy, angle, size, r, g, b, drawContour),
		//
		idx_(count_++)
{
	cout << "Square " << idx_ << " created" << endl;
}

Square::Square(float cx, float cy, float angle, float scale, float r,
			float g, float b, bool drawContour, float vx, float vy, float spin)
	:	GraphicObject2D(cx, cy, angle, scale, r, g, b, drawContour, vx, vy, spin),
		//
		idx_(count_++)
{
	cout << "Square " << idx_ << " created" << endl;
}


void Square::draw() const
{
	glPushMatrix();
	
	// move to object center
	glTranslatef(getCx(), getCy(), 0);
	glRotatef(angle_, 0, 0, 1);
	
//	float halfSize = 0.5f*size_;
//	
//	glColor3f(r_, g_, b_);
//	glBegin(GL_POLYGON);
//		glVertex2f(-halfSize, -halfSize);
//		glVertex2f(+halfSize, -halfSize);
//		glVertex2f(+halfSize, +halfSize);
//		glVertex2f(-halfSize, +halfSize);
//	glEnd();
	glScalef(scale_, scale_, 1.f);	
	
	glColor3f(r_, g_, b_);
	glBegin(GL_POLYGON);
		glVertex2f(-0.5f, -0.5f);
		glVertex2f(+0.5f, -0.5f);
		glVertex2f(+0.5f, +0.5f);
		glVertex2f(-0.5f, +0.5f);
	glEnd();

	if (drawContour_)
	{
		// simply invert the filling color
		glColor3f(1.f-r_, 1.f-g_, 1.f-b_);
		glBegin(GL_LINE_LOOP);
		glVertex2f(-0.5f, -0.5f);
		glVertex2f(+0.5f, -0.5f);
		glVertex2f(+0.5f, +0.5f);
		glVertex2f(-0.5f, +0.5f);
		glEnd();
	}
	
	if (World::drawReferenceFrames)
		drawReferenceFrame();

	glPopMatrix();
}

