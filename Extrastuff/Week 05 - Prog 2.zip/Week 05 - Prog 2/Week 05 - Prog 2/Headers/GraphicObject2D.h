//
//  GraphicObject2D.h
//  Week 03 - Prog 2
//
//  Created by Jean-Yves Hervé on 2024-09-19.
//

#ifndef GRAPHIC_OBJECT_2D_H
#define GRAPHIC_OBJECT_2D_H

#include <stdio.h>

class GraphicObject2D
{
	protected:
		float cx_, cy_, angle_, scale_;
		float r_, g_, b_;
		bool drawContour_;
		float vx_, vy_, spin_;
		
	public:

		GraphicObject2D(float cx, float cy, float angle, float scale,
					float r, float g, float b, bool drawContour);
		GraphicObject2D(float cx, float cy, float angle, float scale,
						float r, float g, float b, bool drawContour,
						float vx, float vy, float spin);

		GraphicObject2D() = delete;
		GraphicObject2D(const GraphicObject2D&) = delete;
		GraphicObject2D(GraphicObject2D&&) = delete;
		GraphicObject2D& operator =(const GraphicObject2D&) = delete;
		GraphicObject2D& operator =(GraphicObject2D&&) = delete;
		virtual ~GraphicObject2D() = default;

		inline float getCx() const
		{
			return cx_;
		}
		
		inline float getCy() const
		{
			return cy_;
		}
		
		//	pure virtual (abstract) function
		virtual void draw() const = 0;
		
		virtual  void update(float dt);

};

#endif // GRAPHIC_OBJECT_2D_H
