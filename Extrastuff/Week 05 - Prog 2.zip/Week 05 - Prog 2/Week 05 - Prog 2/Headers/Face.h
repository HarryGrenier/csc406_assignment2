//
//  Ellipse.hpp
//  Week 05 - Prog 01
//
//  Created by Jean-Yves Hervé on 2024-09-14.
//

#ifndef FACE_H
#define FACE_H

#include "GraphicObject2D.h"

class Face : public GraphicObject2D
{
	private:
	

	public:
	
		Face(float centerX, float centerY, float angle, float scale,
			 float r, float g, float b);
		Face(float centerX, float centerY, float angle, float scale,
			 float r, float g, float b, float vx, float vy, float spin);
		~Face() = default;
		
		//disabled constructors & operators
		Face() = delete;
		Face(const Face& obj) = delete;	// copy
		Face(Face&& obj) = delete;		// move
		Face& operator = (const Face& obj) = delete;	// copy operator
		Face& operator = (Face&& obj) = delete;			// move operator

		void draw() const override;
};

void drawEllipse(float cx, float cy, float angle, float radiusX, float radiusY,
				 float r, float g, float b, bool drawContour);


#endif // FACE_H
