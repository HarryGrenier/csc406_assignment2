//
//  Square.h
//  Week 02 - Prog 2
//
//  Created by Jean-Yves Hervé on 2024-09-10.
//

#ifndef SQUARE_H
#define SQUARE_H

#include "GraphicObject2D.h"

class Square : public GraphicObject2D
{
	private:
		unsigned int idx_;		
		mutable unsigned int renderCount_;
		
		static unsigned int count_;
		
	public:
		Square(float cx, float cy, float angle, float size, float r,
                    float g, float b, bool drawContour);
		Square(float cx, float cy, float angle, float size, float r,
			float g, float b, bool drawContour, float vx, float vy, float spin);
		
		Square() = delete;
		Square(const Square&) = delete;
		Square(Square&&) = delete;
		Square& operator =(const Square&) = delete;
		Square& operator =(Square&&) = delete;
		
		~Square() = default;
		
		void draw() const override;
				
};

#endif //	SQUARE_H
