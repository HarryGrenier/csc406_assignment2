#ifndef WORLD_H
#define WORLD_H

#include <cmath>

/** Struct used to store the coordinates of a Point object.
 */
struct Point{
	
	/** The point's horizontal coordinate.
	 */
	float x;

	/** The point's vertical coordinate.
	 */
	float y;

};

enum WorldType {
					BOX_WORLD,		// objects bounce at the edge of the world
					CYLINDER_WORLD,	//	bounce top-bottom, wrap around left-right,
					TORUS_WORLD	//	wrap all around
};


/** Essentially a set of application-wide global variables defining the
 * dimensions of the "world" and the conversion factors from pixel to world
 * units and back, as well as a few rendering constants.
 *
 */
struct World {

	/**	Minimum x value to get mapped to the display area.
	 *	Set in the main program by a call to setWorldBounds.
	 *	@see setWorldBounds
	 */
	static float X_MIN;

	/**	Maximum x value to get mapped to the display area.
	 *	Set in the main program by a call to setWorldBounds.
	 *	@see setWorldBounds
	 */
	static float X_MAX;

	/**	Minimum y value to get mapped to the display area.
	 *	Set in the main program by a call to setWorldBounds.
	 *	@see setWorldBounds
	 */
	static float Y_MIN;

	/**	Maximum x value to get mapped to the display area.
	 *	Set in the main program by a call to setWorldBounds.
	 *	@see setWorldBounds
	 */
	static float Y_MAX;

	/**	Calculated as X_MAX-X_MIN in the main program by a call to setWorldBounds.
	 *	@see setWorldBounds
	 */
	static float WIDTH;

	/**	Calculated as Y_MAX-Y_MIN in the main program by a call to setWorldBounds.
	 *	@see setWorldBounds
	 */
	static float HEIGHT;

	/**	Scaling factor converting pixel units to world units.
	 *	Calculated in the main program by a call to setWorldBounds.
	 *	@see setWorldBounds
	 */
	static float pixelToWorldRatio;

	/**	Scaling factor converting world units to pixel units.
	 *	Calculated in the main program by a call to setWorldBounds.
	 *	@see setWorldBounds
	 */
	static float worldToPixelRatio;
	
	/**	This one is really equal to pixelToWorldRatio, but it looks confusing
	 *	to write glScalef(pixelToWorldRatio, pixelToWorldRatio, 1.f);
	 *	right before trying to drawe in pixel units.
	 *	@see setWorldBounds
	 */
	static float drawInPixelScale;
	
	static WorldType worldType;

	static bool drawReferenceFrames;
	
	/** Function called through the initialization of a global variable in the
	 *	main program.  Although the user specifies dimensions for the rendering pane,
	 *	the function may set different values that agree better with the world
	 *	aspect ratio.
	 * @param xmin	Minimum x value to get mapped to the display area.
	 * @param xmax	Maximum x value to get mapped to the display area.
	 * @param ymin	Minimum y value to get mapped to the display area.
	 * @param ymax	Maximum y value to get mapped to the display area.
	 * @param paneWidth		user-set width of the redering pane
	 * @param paneHeight	user-set height of the redering pane
	 * */
	static void setWorldBounds(float xmin, float xmax, float ymin, float ymax,
								int& paneWidth, int& paneHeight);	

};

void drawReferenceFrame(void);

Point pixelToWorld(float ix, float iy);
Point worldToPixel(float wx, float wy);

#endif  //  WORLD_H
