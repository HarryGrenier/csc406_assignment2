//
//  Rectangle.h
//  Template Project
//
//  Created by Jean-Yves Hervé on 2023-10-12.  Revised 2024-10-03
//


#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "GraphicObject2D.h"

class Rectangle : public GraphicObject2D
{
	private:
	
		float width_, height_;
			
	public:
	
		Rectangle(float centerX, float centerY, float angle, float width, float height,
				float r, float g, float b, bool drawContour);
		Rectangle(float centerX, float centerY, float angle, float width, float height,
				float r, float g, float b, bool drawContour, float vx, float vy, float spin);
		~Rectangle() = default;
		
		void draw() const override;

		//disabled constructors & operators
		Rectangle() = delete;
		Rectangle(const Rectangle& obj) = delete;	// copy
		Rectangle(Rectangle&& obj) = delete;		// move
		Rectangle& operator = (const Rectangle& obj) = delete;	// copy operator
		Rectangle& operator = (Rectangle&& obj) = delete;		// move operator

};

#endif // RECTANGLE_H
