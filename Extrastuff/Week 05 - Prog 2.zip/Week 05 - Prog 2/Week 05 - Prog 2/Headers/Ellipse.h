//
//  Ellipse.hpp
//
//  Created by Jean-Yves Hervé on 2023-09-14.  Revised 2024-10-03
//

#ifndef ELLIPSE_H
#define ELLIPSE_H

#include "GraphicObject2D.h"

class Ellipse : public GraphicObject2D
{
	friend bool initEllipseFunc();
	friend void drawDisk();
	
	private:
	
		float radiusX_, radiusY_;
			
		static const int numCirclePts_;
		static float** circlePts_;

	public:
	
		Ellipse(float centerX, float centerY, float angle, float radiusX, float radiusY,
				float r, float g, float b, bool drawContour);
		Ellipse(float centerX, float centerY, float angle, float radiusX, float radiusY,
				float r, float g, float b, bool drawContour, float vx, float vy, float spin);
		~Ellipse() = default;
		
		void draw() const override;

		//disabled constructors & operators
		Ellipse() = delete;
		Ellipse(const Ellipse& obj) = delete;	// copy
		Ellipse(Ellipse&& obj) = delete;		// move
		Ellipse& operator = (const Ellipse& obj) = delete;	// copy operator
		Ellipse& operator = (Ellipse&& obj) = delete;		// move operator

};

bool initEllipseFunc();
void drawDisk();

#endif // ELLIPSE_H
