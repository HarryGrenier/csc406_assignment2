//
//  Triangle.h
//  Week 05 - Prog 1
//
//  Created by Jean-Yves Hervé on 2024-09-10.
//

#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "GraphicObject2D.h"

class Triangle : public GraphicObject2D
{
	private:
		unsigned int idx_;
		
		static float xy_[3][2];
		static unsigned int count_;
		
	public:
		Triangle(float cx, float cy, float angle, float radius, float r,
			float g, float b, bool drawContour);
		Triangle(float cx, float cy, float angle, float radius, float r,
			float g, float b, bool drawContour, float vx, float vy, float spin);
		
		Triangle() = delete;
		Triangle(const Triangle&) = delete;
		Triangle(Triangle&&) = delete;
		Triangle& operator =(const Triangle&) = delete;
		Triangle& operator =(Triangle&&) = delete;
		~Triangle() = default;
		
		void draw() const override;
		void update(float dt) override;
		
};

#endif //	TRIANGLE_H
